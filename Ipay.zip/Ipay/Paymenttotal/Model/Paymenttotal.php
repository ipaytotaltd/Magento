<?php
namespace Ipay\Paymenttotal\Model;
use Magento\Framework\Exception\LocalizedException;
use Magento\Sales\Model\Order;
class Paymenttotal extends \Magento\Payment\Model\Method\Cc
{
    const CODE = 'ipay_paymenttotal';
    protected $scopeConfig;
    protected $_code = self::CODE;
    protected $_canAuthorize = true;
    protected $_canCapture = true;
    const IPAY_PAYMENT = 'payment/ipay_paymenttotal/ipay';
  

    /**
     * Capture Payment.
     *
     * @param \Magento\Payment\Model\InfoInterface $payment
     * @param float $amount
     * @return $this
     */
    public function capture(\Magento\Payment\Model\InfoInterface $payment, $amount)
    {
        try {
           
            //check if payment has been authorized
            if(is_null($payment->getParentTransactionId())) {
                $this->authorize($payment, $amount);
            }

            //build array of payment data for API request.
            $request = [
                'capture_amount' => $amount,
                //any other fields, api key, etc.
            ];


/** @var \Magento\Sales\Model\Order $order */
            $order = $payment->getOrder();
     
            /** @var \Magento\Sales\Model\Order\Address $billing */
            $billing = $order->getBillingAddress();
            
            $url = "https://ipaytotal.solutions/api/transaction";
            $ipay = $this->_scopeConfig->getValue('payment/ipay_paymenttotal/ipay', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
            if(strlen($payment->getCcExpMonth())==1)
            {
                $getCcExpMonth="0".$payment->getCcExpMonth();
            }
            else
            {
                $getCcExpMonth=$payment->getCcExpMonth();
            }
            $key = $ipay;
               $data = [
                    'api_key' => $key,
                    'first_name' => $billing->getFirstname(),
                    'last_name' => $billing->getLastname(),
                    'address' => $billing->getStreetLine(1),
                    'country' => $billing->getCountryId(),
                    'state' => 'AK', // if your country US then use only 2 letter state code.
                    'city' => $billing->getCity(),
                    'zip' => $billing->getPostcode(),
                    'email' => $order->getCustomerEmail(),
                    'phone_no' => $billing->getTelephone(),
                    'card_type' =>"2", // See your card type in list
                    'amount' => $payment->getData('amount_ordered'),
                    'currency' => strtoupper($order->getBaseCurrencyCode()),
                    'card_no' => $payment->getData('cc_number'),
                    'ccExpiryMonth' => $getCcExpMonth,
                    'ccExpiryYear' => $payment->getCcExpYear(),
                    'cvvNumber' => $payment->getCcCid(),
                ]; 
               
                // $str="getCcType--".$payment->getCcType()."--getCcExpMonth-".$payment->getCcExpMonth()."--getCcExpYear-".$payment->getCcExpYear()."---".$payment->getCcNumberEnc()."----".json_encode($payment->getData())."====".json_encode($requestData)."<br>";

                $curl = curl_init();
                        curl_setopt($curl, CURLOPT_URL, $url);
                        curl_setopt($curl, CURLOPT_POST, 1);
                        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));
                        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
                        curl_setopt($curl, CURLOPT_HTTPHEADER,[
                            'Content-Type: application/json'
                        ]);
                        $responseD = curl_exec($curl);
                        curl_close($curl);
                        $responseData = json_decode($responseD); 

                        $message = "";
                        $msg =0;
                        $status=$responseData->status;

                       
                     if($status=='success')
                       {
                           //todo handle response
                           //make API request to credit card processor.
                         $response = $this->makeCaptureRequest($request);
                            //transaction is done.
                            $payment->setIsTransactionClosed(true);
                            
                       }
                       else
                       {
                             // $this->debug($payment->getData(), $e->getMessage());
                            $response = $this->makeCaptureRequest($request);
                            $error_code="card_declined";
                             if ($error_code === "card_declined") {
                    $errorMsg = 'Charge was declined. Please, contact you bank for more information or use a different card.';
                        } else {
                            $errorMsg = $e->getMessage();
                        }
                        $this->_logger->error(__($errorMsg));
                          $payment->setSkipTransactionCreation(true);
                        $orderId=$order->getId();
                        $state = Order::STATE_PAYMENT_PENDING;
                        $status = Order::STATE_PAYMENT_PENDING;
                        $comment = $errorMsg;
                        $isNotified = false;
                        $order->setState($state);
                        $order->setStatus($status);
                        $order->addStatusToHistory($order->getStatus(), $comment);
                        $order->save(); 
                        //$payment->setIsTransactionPending(true); 
                        //$payment->setIsFraudDetected(true);

                            //transaction is done.
                           // $payment->setIsTransactionPending(true);
                       }
            
            
        } catch (\Exception $e) {
            $this->debug($payment->getData(), $e->getMessage());
        }
        

        return $this;
    }

    /**
     * Authorize a payment.
     *
     * @param \Magento\Payment\Model\InfoInterface $payment
     * @param float $amount
     * @return $this
     */
    public function authorize(\Magento\Payment\Model\InfoInterface $payment, $amount)
    {
        try {
              // $this->debug($payment->getData(), $e->getMessage());
            $request = [
                'cc_type' => $payment->getCcType(),
                'cc_exp_month' => $payment->getCcExpMonth(),
                'cc_exp_year' => $payment->getCcExpYear(),
                'cc_number' => $payment->getCcNumberEnc(),
                'amount' => $amount
            ];
            $response = $this->makeAuthRequest($request);
            ///build array of payment data for API request.
            $request = [
                'cc_type' => $payment->getCcType(),
                'cc_exp_month' => $payment->getCcExpMonth(),
                'cc_exp_year' => $payment->getCcExpYear(),
                'cc_number' => $payment->getCcNumberEnc(),
                'amount' => $amount
            ];
          
           

          
           

        } catch (\Exception $e) {
            $this->debug($payment->getData(), $e->getMessage());
        }
        if(isset($response['transactionID'])) {
            // $this->debug("Tees");
            // Successful auth request.
            // Set the transaction id on the payment so the capture request knows auth has happened.
            $payment->setTransactionId($response['transactionID']);
            $payment->setParentTransactionId($response['transactionID']);
           

        }

        //processing is not done yet.
        $payment->setIsTransactionClosed(0);

        return $this;
    }

    /**
     * Set the payment action to authorize_and_capture
     *
     * @return string
     */
    public function getConfigPaymentAction()
    {
        return self::ACTION_AUTHORIZE_CAPTURE;
    }

    /**
     * Test method to handle an API call for authorization request.
     *
     * @param $request
     * @return array
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function makeAuthRequest($request)
    {
        $response = ['transactionId' => 123]; //todo implement API call for auth request.

        if(!$response) {
            throw new \Magento\Framework\Exception\LocalizedException(__('Failed auth request.'));
        }

        return $response;
    }

    /**
     * Test method to handle an API call for capture request.
     *
     * @param $request
     * @return array
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function makeCaptureRequest($request)
    {
        $response = ['success']; //todo implement API call for capture request.

        if(!$response) {
            throw new \Magento\Framework\Exception\LocalizedException(__('Failed capture request.'));
        }

        return $response;
    }
}
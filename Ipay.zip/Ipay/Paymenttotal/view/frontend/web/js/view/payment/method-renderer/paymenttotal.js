define([
        'jquery',
        'Magento_Payment/js/view/payment/cc-form'
    ],
    function ($, Component) {
        'use strict';

        return Component.extend({
            defaults: {
                template: 'Ipay_Paymenttotal/payment/paymenttotal'
            },

            context: function() {
                return this;
            },

            getCode: function() {
                return 'ipay_paymenttotal';
            },

            isActive: function() {
                return true;
            }
        });
    }
);
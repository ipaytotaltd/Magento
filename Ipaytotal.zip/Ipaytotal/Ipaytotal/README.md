## HOW TO INSTALL Ipaytotal module for magento 2.3.2

- Copy all files to /app/code
- run command in your command line php bin/magento setup:upgrade
- run command in your command line php bin/magento setup:static-content:deploy
- Go to magento administration Stores -> General -> Sales -> Ipaytotal
- Fill our your Merchant Gateway Key you obtained from Ipaytotal administration
- Set test mode to now
- Set Enabled yes


define(
    [
        'uiComponent',
        'Magento_Checkout/js/model/payment/renderer-list'
    ],
    function (
        Component,
        rendererList
    ) {
        'use strict';
        rendererList.push(
            {
                type: 'ipaytotal',
                component: 'Ipaytotal_Ipaytotal/js/view/payment/method-renderer/ipaytotal-method'
            }
        );
        return Component.extend({});
    }
);